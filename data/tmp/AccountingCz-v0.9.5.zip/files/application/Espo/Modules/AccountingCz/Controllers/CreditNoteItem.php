<?php

namespace Espo\Modules\AccountingCz\Controllers;

class CreditNoteItem extends \Espo\Modules\Autocrm\Classes\Abstract\Controllers\Item
{
}
