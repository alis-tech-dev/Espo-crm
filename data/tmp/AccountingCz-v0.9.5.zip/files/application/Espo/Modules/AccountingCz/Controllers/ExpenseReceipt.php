<?php

namespace Espo\Modules\AccountingCz\Controllers;

use Espo\Core\Templates\Controllers\Base;

class ExpenseReceipt extends Base
{
}
