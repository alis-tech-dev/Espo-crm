<?php

namespace Espo\Modules\AccountingCz\Controllers;

class IssuedTaxDocument extends \Espo\Modules\Accounting\Classes\Abstract\Controllers\InvoiceLike
{
}
