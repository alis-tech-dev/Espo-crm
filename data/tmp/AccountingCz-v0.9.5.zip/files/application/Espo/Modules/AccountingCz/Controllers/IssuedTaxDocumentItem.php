<?php

namespace Espo\Modules\AccountingCz\Controllers;

class IssuedTaxDocumentItem extends \Espo\Modules\Autocrm\Classes\Abstract\Controllers\Item
{
}
