<?php

namespace Espo\Modules\AccountingCz\Controllers;

class PartialPayments extends \Espo\Core\Templates\Controllers\Base
{
}
