<?php

namespace Espo\Modules\AccountingCz\Controllers;

class ProformaInvoice extends \Espo\Modules\Accounting\Classes\Abstract\Controllers\InvoiceLike
{
}
