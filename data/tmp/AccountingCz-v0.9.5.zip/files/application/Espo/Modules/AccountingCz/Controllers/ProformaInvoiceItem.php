<?php

namespace Espo\Modules\AccountingCz\Controllers;

use Espo\Modules\Autocrm\Classes\Abstract\Controllers\Item;

class ProformaInvoiceItem extends Item
{
}
