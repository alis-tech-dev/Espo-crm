<?php

namespace Espo\Modules\AccountingCz\Controllers;

class ReceivedProformaInvoiceItem extends \Espo\Modules\Autocrm\Classes\Abstract\Controllers\Item
{
}
