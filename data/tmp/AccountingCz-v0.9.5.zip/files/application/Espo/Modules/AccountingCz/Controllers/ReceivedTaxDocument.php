<?php

namespace Espo\Modules\AccountingCz\Controllers;

class ReceivedTaxDocument extends \Espo\Modules\Accounting\Classes\Abstract\Controllers\InvoiceLike
{
}
