<?php

namespace Espo\Modules\AccountingCz\Controllers;

class ReceivedTaxDocumentItem extends \Espo\Modules\Autocrm\Classes\Abstract\Controllers\Item
{
}
