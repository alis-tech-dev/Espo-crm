<?php

namespace Espo\Modules\AccountingCz\Entities;

class CreditNote extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'CreditNote';
}
