<?php

namespace Espo\Modules\AccountingCz\Entities;

class IssuedTaxDocument extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'IssuedTaxDocument';
}
