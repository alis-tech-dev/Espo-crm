<?php

namespace Espo\Modules\AccountingCz\Entities;

class PartialPayments extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'PartialPayments';

    protected $entityType = 'PartialPayments';
}
