<?php

namespace Espo\Modules\AccountingCz\Entities;

use Espo\Core\Templates\Entities\Base;

class Payment extends Base
{
    public const ENTITY_TYPE = 'Payment';
}
