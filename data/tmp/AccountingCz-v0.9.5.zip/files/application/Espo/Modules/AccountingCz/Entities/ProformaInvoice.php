<?php

namespace Espo\Modules\AccountingCz\Entities;

class ProformaInvoice extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'ProformaInvoice';
}
