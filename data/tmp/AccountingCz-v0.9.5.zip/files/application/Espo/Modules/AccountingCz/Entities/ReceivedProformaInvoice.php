<?php

namespace Espo\Modules\AccountingCz\Entities;

class ReceivedProformaInvoice extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'ReceivedProformaInvoice';
}
