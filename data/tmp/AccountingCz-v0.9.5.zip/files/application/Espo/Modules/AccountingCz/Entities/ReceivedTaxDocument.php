<?php

namespace Espo\Modules\AccountingCz\Entities;

class ReceivedTaxDocument extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'ReceivedTaxDocument';
}
