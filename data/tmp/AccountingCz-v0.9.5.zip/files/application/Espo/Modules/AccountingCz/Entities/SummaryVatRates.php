<?php

namespace Espo\Modules\AccountingCz\Entities;

class SummaryVatRates extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'SummaryVatRates';
}
