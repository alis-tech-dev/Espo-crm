<?php

namespace Espo\Modules\AccountingCz\Repositories;

class CreditNote extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}
