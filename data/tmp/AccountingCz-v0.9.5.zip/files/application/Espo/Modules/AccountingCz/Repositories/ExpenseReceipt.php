<?php

namespace Espo\Modules\AccountingCz\Repositories;

class ExpenseReceipt extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}
