<?php

namespace Espo\Modules\AccountingCz\Repositories;

class Invoice extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}