<?php

namespace Espo\Modules\AccountingCz\Repositories;

class IssuedTaxDocument extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}