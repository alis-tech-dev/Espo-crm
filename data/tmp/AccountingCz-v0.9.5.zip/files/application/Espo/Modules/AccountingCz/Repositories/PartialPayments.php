<?php

namespace Espo\Modules\AccountingCz\Repositories;

class PartialPayments extends \Espo\Core\Templates\Repositories\Base
{
}
