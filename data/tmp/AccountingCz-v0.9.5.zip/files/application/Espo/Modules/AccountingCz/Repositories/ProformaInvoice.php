<?php

namespace Espo\Modules\AccountingCz\Repositories;

class ProformaInvoice extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}