<?php

namespace Espo\Modules\AccountingCz\Repositories;

class ReceivedTaxDocument extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}