<?php

namespace Espo\Modules\AccountingCz\Repositories;

class RevenueReceipt extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}
