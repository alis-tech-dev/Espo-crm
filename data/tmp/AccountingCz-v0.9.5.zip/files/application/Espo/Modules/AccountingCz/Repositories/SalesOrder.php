<?php

namespace Espo\Modules\AccountingCz\Repositories;

class SalesOrder extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}