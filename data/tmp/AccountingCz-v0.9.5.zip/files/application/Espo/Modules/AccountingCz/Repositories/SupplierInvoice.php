<?php

namespace Espo\Modules\AccountingCz\Repositories;

class SupplierInvoice extends \Espo\Modules\AccountingCz\Classes\Abstract\Repositories\InvoiceLike
{
}