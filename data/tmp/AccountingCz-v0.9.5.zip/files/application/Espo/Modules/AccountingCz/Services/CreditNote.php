<?php

namespace Espo\Modules\AccountingCz\Services;

class CreditNote extends \Espo\Modules\AccountingCz\Classes\Abstract\Services\InvoiceLike
{
}
