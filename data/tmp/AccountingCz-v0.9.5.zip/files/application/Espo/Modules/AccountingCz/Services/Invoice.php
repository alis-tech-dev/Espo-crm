<?php

namespace Espo\Modules\AccountingCz\Services;

class Invoice extends \Espo\Modules\AccountingCz\Classes\Abstract\Services\InvoiceLike
{
}
