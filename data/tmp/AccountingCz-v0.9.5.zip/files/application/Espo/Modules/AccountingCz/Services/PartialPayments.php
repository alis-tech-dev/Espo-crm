<?php

namespace Espo\Modules\AccountingCz\Services;

class PartialPayments extends \Espo\Modules\Accounting\Classes\Abstract\Services\InvoiceLike
{
}
