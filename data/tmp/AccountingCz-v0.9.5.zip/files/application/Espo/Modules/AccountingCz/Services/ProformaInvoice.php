<?php

namespace Espo\Modules\AccountingCz\Services;

class ProformaInvoice extends \Espo\Modules\AccountingCz\Classes\Abstract\Services\InvoiceLike
{
}
