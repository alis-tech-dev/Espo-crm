<?php

namespace Espo\Modules\AccountingCz\Services;

class ReceivedProformaInvoice extends \Espo\Modules\AccountingCz\Classes\Abstract\Services\InvoiceLike
{
}
