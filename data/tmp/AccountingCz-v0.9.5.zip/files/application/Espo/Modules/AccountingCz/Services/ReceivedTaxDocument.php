<?php

namespace Espo\Modules\AccountingCz\Services;

class ReceivedTaxDocument extends \Espo\Modules\AccountingCz\Classes\Abstract\Services\InvoiceLike
{
}
