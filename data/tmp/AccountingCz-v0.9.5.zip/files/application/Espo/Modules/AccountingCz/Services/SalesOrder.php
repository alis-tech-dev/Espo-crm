<?php

namespace Espo\Modules\AccountingCz\Services;

class SalesOrder extends \Espo\Modules\AccountingCz\Classes\Abstract\Services\InvoiceLike
{
}
