<?php

namespace Espo\Modules\AccountingCz\Services;

use Espo\Core\Templates\Services\Base;

class SummaryVatRates extends Base
{
}
