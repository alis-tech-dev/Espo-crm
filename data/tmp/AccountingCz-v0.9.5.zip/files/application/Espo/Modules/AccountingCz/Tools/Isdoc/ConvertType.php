<?php

namespace Espo\Modules\AccountingCz\Tools\Isdoc;

enum ConvertType {
    case ToIsdoc;
    case FromIsdoc;
}