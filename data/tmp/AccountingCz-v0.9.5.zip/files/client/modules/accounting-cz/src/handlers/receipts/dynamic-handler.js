define(['dynamic-handler'], DynamicHandler => {

    return class extends DynamicHandler {

        // init() {

        //     this.recordView.once('after:render', this.afterRender());

        // }

        // afterRender() {

        //     if (this.model.isNew() && this.model.get('amount')) {

        //         const fieldView = this.recordView.getFieldView('amount');

        //         console.log("fieldView", fieldView);

        //     }

        // }

    }  

}); 
