define(['views/fields/link-multiple'], LinkMultipleField => {
	return class extends LinkMultipleField {
		createDisabled = true;
	};
});
