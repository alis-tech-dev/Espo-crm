<?php

use Espo\Core\{
    Container,
    DataManager,
};
use Espo\Core\InjectableFactory;
use Espo\Core\Utils\Config;
use Espo\Core\Utils\Config\ConfigWriter;
use Espo\ORM\EntityManager;
use Espo\Core\Utils\File\Manager as FileManager;
use Espo\Entities\Template;
use Espo\ORM\Query\Part\Condition as Cond;
use Espo\ORM\Query\Part\Expression as Expr;

class AfterInstall
{
    private const TAB_LIST_ENTITIES = [];
    private const DEFAULT_CONFIG = [
        'supplierVATpayer' => false,
        'customInvoiceNames' => false,
    ];

    private const PDF_TEMPLATES_DIR = 'application/Espo/Modules/AccountingCz/Resources/defaultPdfTemplates';

    private Config $config;
    private ConfigWriter $configWriter;
    private DataManager $dataManager;
    private EntityManager $entityManager;
    private FileManager $fileManager;

    public function run(Container $container, array $params = []): void
    {
        $this->loadDependencies($container);

        if (empty($params['isUpgrade'])) {
            $this->addEntitiesToTabList();
        }

        $this->defaultConfig();

        $this->defaultPdfTemplates();

        $this->clearCache();
    }

    private function loadDependencies(Container $container): void
    {
        $injectableFactory = $container->getByClass(InjectableFactory::class);

        $this->config = $container->getByClass(Config::class);
        $this->configWriter = $injectableFactory->create(ConfigWriter::class);
        $this->dataManager = $container->getByClass(DataManager::class);
        $this->entityManager = $container->getByClass(EntityManager::class);
        $this->fileManager = $container->getByClass(FileManager::class);
    }

    private function defaultConfig(): void
    {
        foreach (self::DEFAULT_CONFIG as $key => $value) {
            if (!$this->config->has($key)) {
                $this->configWriter->set($key, $value);
            }
        }

        $this->configWriter->save();
    }

    private function addEntitiesToTabList(): void
    {
        $tabList = $this->config->get('tabList') ?? [];

        foreach (self::TAB_LIST_ENTITIES as $entity) {
            if (!in_array($entity, $tabList, true)) {
                $tabList[] = $entity;
            }
        }

        $this->configWriter->set('tabList', $tabList);
        $this->configWriter->save();
    }

    private function clearCache(): void
    {
        try {
            $this->dataManager->clearCache();
        } catch (\Exception) {
        }
    }

    private function defaultPdfTemplates(): void
    {
        $dirs = $this->fileManager->getDirList(self::PDF_TEMPLATES_DIR);

        foreach ($dirs as $entityType) {
            $path = self::PDF_TEMPLATES_DIR . "/{$entityType}";

            $fields = [
                'name' => "$entityType (default) [NEUPRAVOVAT]",
                'entityType' => $entityType,
                'body' =>  $this->fileManager->getContents($path . '/body.html'),
                'footer' => $this->fileManager->getContents($path . '/footer.html'),
            ];

            $template = $this->entityManager->getRDBRepositoryByClass(Template::class)
                ->where(
                    Cond::and(
                        Cond::equal(Expr::column("entityType"), $entityType),
                        Cond::equal(Expr::column("name"), $fields['name'])
                    )
                )
                ->findOne() ?? $this->entityManager->getNewEntity(Template::ENTITY_TYPE);

            $template->set($fields);

            $this->entityManager->saveEntity($template);
        }
    }
}
