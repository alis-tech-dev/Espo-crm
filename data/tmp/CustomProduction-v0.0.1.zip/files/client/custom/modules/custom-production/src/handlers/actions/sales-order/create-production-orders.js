define(['action-handler'], Dep => {
	return class extends Dep {
		actionCreateProductionOrders() {
			const id = this.view.model.get('id');

			this.view
				.ajaxPostRequest(`SalesOrder/createProductionOrders/${id}`)
				.then(response => {
					switch (response.result) {
						case 'Success':
							this.view.model.trigger('update-all');
							Espo.Ui.success(this.view.translate('Done'));

							this.view.model.set('status', 'In Production');
							this.view.model.save();
							break;
						case 'NoProducts':
							Espo.Ui.info('Žádné produkty');
							break;
						default:
							Espo.Ui.error('Neznámá odpověď od serveru');
					}
				});
		}

		init() {
			this.controlVisibility();

			this.view.listenTo(
				this.view.model,
				'change:status',
				this.controlVisibility.bind(this),
			);
		}

		controlVisibility() {
			if (this.view.model.get('status') === 'In Production') {
				this.view.hideHeaderActionItem('createProductionOrders');
			} else {
				this.view.showHeaderActionItem('createProductionOrders');
			}
		}
	};
});
