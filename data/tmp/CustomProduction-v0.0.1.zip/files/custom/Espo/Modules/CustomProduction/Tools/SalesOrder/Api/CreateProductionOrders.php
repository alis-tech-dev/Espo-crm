<?php

namespace Espo\Modules\CustomProduction\Tools\SalesOrder\Api;

use Espo\Core\Api\Action;
use Espo\Core\Api\Request;
use Espo\Core\Api\Response;
use Espo\Core\Api\ResponseComposer;
use Espo\Core\Di\RecordServiceContainerAware;
use Espo\Core\Di\RecordServiceContainerSetter;
use Espo\Core\Di\UserAware;
use Espo\Core\Di\UserSetter;
use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Exceptions\NotFound;
use Espo\ORM\EntityManager;

class CreateProductionOrders implements Action, RecordServiceContainerAware, UserAware {

    use RecordServiceContainerSetter;
    use UserSetter;

    public function __construct(
        private readonly EntityManager $entityManager,
    ){}

    public function process(Request $request): Response
    {
        $id = $request->getRouteParam('id');

        if (is_null($id)) {
            throw new BadRequest();
        }

        $salesOrder = $this
            ->recordServiceContainer
            ->get('SalesOrder')
            ->getEntity($id);

        if (is_null($salesOrder)) {
            throw new NotFound();
        }

        $items = $salesOrder->get('itemsRecordList') ?? [];

        $em = $this->entityManager;

        $hasProducts = false;

        $em->getTransactionManager()->run(function() use ($items, $em, $salesOrder, &$hasProducts) {
            foreach ($items as $item) {
                $productId = $item->productId;

                if (is_null($productId)){
                    continue;
                }

                $product = $em->getEntity('Product', $productId);

                if (!$product){
                    throw new NotFound();
                }

                $em->createEntity('ProductionOrder', [
                    'productId' => $productId,
                    'name' => $product->get('name'),
                    'salesOrderId' => $salesOrder->getId(),
                    'assignedUserId' => $this->user->getId(),
                ]);

                $hasProducts = true;
            }
        });

        $result = $hasProducts ? 'Success' : 'NoProducts';

        return ResponseComposer::json([
            'result' => $result
        ]);
    }
}