<?php

namespace Espo\Modules\ExportXml\Controllers;

class XmlTemplate extends \Espo\Core\Templates\Controllers\Base
{

}
