<?php

namespace Espo\Modules\ExportXml\Repositories;

class XmlTemplate extends \Espo\Core\Templates\Repositories\Base
{

}
