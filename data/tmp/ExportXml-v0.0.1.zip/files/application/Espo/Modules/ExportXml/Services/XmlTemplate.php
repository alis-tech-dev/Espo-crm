<?php

namespace Espo\Modules\ExportXml\Services;

class XmlTemplate extends \Espo\Core\Templates\Services\Base
{

}
