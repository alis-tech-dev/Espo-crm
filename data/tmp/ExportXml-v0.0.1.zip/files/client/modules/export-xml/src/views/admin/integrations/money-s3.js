define('export-xml:views/admin/integrations/money-s3', ['views/admin/integrations/edit'], function (Dep) {
    return Dep.extend({

    });
});
