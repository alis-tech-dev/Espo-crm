define('export-xml:views/admin/integrations/pohoda', ['views/admin/integrations/edit'], function (Dep) {
    return Dep.extend({

    });
});
