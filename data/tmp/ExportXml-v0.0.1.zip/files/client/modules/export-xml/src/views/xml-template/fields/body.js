define('export-xml:views/xml-template/fields/body', ['views/fields/text'], function (Dep) {
    return Dep.extend({


    });
});
