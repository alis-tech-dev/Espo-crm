define('export-xml:views/xml-template/record/detail', ['views/record/detail'], function (Dep){
    return Dep.extend({
        
    });
});
