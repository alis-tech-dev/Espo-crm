define('export-xml:views/xml-template/record/edit', ['views/record/edit'], function (Dep) {
    return Dep.extend({

    });
});
