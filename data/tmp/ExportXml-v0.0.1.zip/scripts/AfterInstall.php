<?php

use Espo\Core\Container;
use Espo\Core\Utils\File\Manager as FileManager;
use Espo\ORM\EntityManager;

class AfterInstall
{
    protected const TAB_LIST_ENTITIES = [];
    protected const DEFAULT_CONFIG = [];

    protected Container $container;

    public function run(Container $container, array $params = []): void
    {
        $this->container = $container;

        if (empty($params['isUpgrade'])) {
            $this->addEntitiesToTabList();
        }

        $this->addDefaultRecords();

        $this->defaultConfig();

        $this->clearCache();
    }

    protected function defaultConfig(): void
    {
        $config = $this->container->get('config');

        foreach (self::DEFAULT_CONFIG as $key => $value) {
            if (!$config->has($key)) {
                $config->set($key, $value);
            }
        }

        $config->save();
    }

    protected function addEntitiesToTabList(): void
    {
        $config = $this->container->get('config');
        $tabList = $config->get('tabList');

        foreach (self::TAB_LIST_ENTITIES as $entity) {
            if (!in_array($entity, $tabList, true)) {
                $tabList[] = $entity;
            }
        }

        $config->set('tabList', $tabList);
        $config->save();
    }

    protected function addDefaultRecords(): void
    {
        /** @var EntityManager $entityManager */
        $entityManager = $this->container->get('entityManager');

        $fileManager = $this->getFileManager();

        $dir = __DIR__ . '/DefaultRecords';

        $fileList = $fileManager->getFileList($dir, false, '\.php$');

        foreach ($fileList as $file) {
            $data = $fileManager->getPhpContents("{$dir}/{$file}");
            $entityType = pathinfo($file, PATHINFO_FILENAME);

            foreach ($data as $record){
                $id = $record->id;

                if ($entityManager->getEntity($entityType, $id)) {
                    continue;
                }

                $entityManager->createEntity($entityType, $record);
            }
        }
    }

    protected function getFileManager(): FileManager
    {
        return $this->container->get('injectableFactory')->create(FileManager::class);
    }

    protected function clearCache(): void
    {
        try {
            $this->container->get('dataManager')->clearCache();
        } catch (Exception) {
        }
    }
}
