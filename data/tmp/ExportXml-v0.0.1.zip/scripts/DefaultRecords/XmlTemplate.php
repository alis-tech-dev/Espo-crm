<?php

return [
    (object)[
        'id' => 'MoneyS3',
        'name' => 'MoneyS3',
        'entityType' => 'Invoice',
        'title' => '{{name}}.xml',
        'body' => '<?xml version="1.0" encoding="UTF-8"?><MoneyData>
        <SeznamObjPrij>
            <ObjPrij>
                <Doklad>{{name}}</Doklad>
                <PrimDoklad>{{name}}</PrimDoklad>
                <VarSymbol>{{variableSymbol}}</VarSymbol>
                <Popis>Objednávka z eshopu č.{{name}}</Popis>
                <Vystaveno></Vystaveno>
                <Vyridit_do></Vyridit_do>
                <DodOdb>
                    <ObchNazev> </ObchNazev>
                    <ObchAdresa>
                        <Ulice></Ulice>
                        <Misto></Misto>
                        <PSC></PSC>
                        <Stat> </Stat>
                    </ObchAdresa>
                    <FaktNazev></FaktNazev>
                    <ICO></ICO>
                    <DIC></DIC>
                    <FaktAdresa>
                        <Ulice></Ulice>
                        <Misto></Misto>
                        <PSC></PSC>
                        <Stat> </Stat>
                    </FaktAdresa>
                    <Nazev></Nazev>
                    <Adresa>
                        <Ulice></Ulice>
                        <Misto></Misto>
                        <PSC></PSC>
                        <Stat> </Stat>
                    </Adresa>
                    <Tel>
                        <Cislo></Cislo>
                    </Tel>
                    <Fax>
                        <Pred></Pred>
                    </Fax>
                    <EMail></EMail>
                    <WWW>www.money.cz</WWW>
                    <PlatceDPH>1</PlatceDPH>
                    <FyzOsoba>1</FyzOsoba>
                    <Banka>eBanka a. s.</Banka>
                    <Ucet>67890</Ucet>
                    <KodBanky>2400</KodBanky>
                    <KodPartn>OUT01</KodPartn>
                </DodOdb>
                <KonecPrij>
                    <Nazev> </Nazev>
                    <Adresa>
                        <Ulice></Ulice>
                        <Misto></Misto>
                        <PSC></PSC>
                        <Stat> </Stat>
                        <KodStatu></KodStatu>
                    </Adresa>
                    <Tel>
                        <Cislo></Cislo>
                    </Tel>
                    <EMail></EMail>
                    <WWW></WWW>
                    <ICO></ICO>
                    <DIC></DIC>
                    <PlatceDPH></PlatceDPH>
                    <FyzOsoba></FyzOsoba>
                    <Banka></Banka>
                    <Ucet></Ucet>
                    <KodBanky></KodBanky>
                    <KodPartn></KodPartn>
                </KonecPrij>
                <KPFromOdb></KPFromOdb>
                <SouhrnDPH></SouhrnDPH>
                <Celkem></Celkem>
                <DRada></DRada>
                <DCislo></DCislo>
                <Stredisko></Stredisko>
                <Zakazka></Zakazka>
                <NeRezervov></NeRezervov>
                <MenaKod>CZK</MenaKod>
                <MenaSymb>Kč</MenaSymb>
                <PevneCeny>1</PevneCeny>
                <PlatPodm></PlatPodm>
                <ZpDopravy></ZpDopravy>
                <CasVystave></CasVystave>
                <DatumVysta></DatumVysta>
                <Nadpis>Přijatá objednávka</Nadpis>
                <VyriditNej></VyriditNej>
                <NeVyrizova>0</NeVyrizova>
                <SizDecDPH>0</SizDecDPH>
                <SizDecCelk>0</SizDecCelk>
                <ZobrPoznVy>0</ZobrPoznVy>
                <ZpVypDPH>1</ZpVypDPH>
                <SazbaDPH1>15</SazbaDPH1>
                <SazbaDPH2>21</SazbaDPH2>
                <Sleva>0</Sleva>
                <SeznamPolozek>
                    {{#each items}}
                    <Polozka>
                        <Popis>{{name}}</Popis>
                        <PocetMJ>{{quantity}}</PocetMJ>
                        <SazbaDPH>{{taxRate}}</SazbaDPH>
                        <TypCeny>1</TypCeny>
                        <Sleva>0</Sleva>
                        <Vystaveno></Vystaveno>
                        <Vyridit_do></Vyridit_do>
                        <Poradi>1</Poradi>
                        <Hmotnost>0</Hmotnost>
                        <PredPC>0</PredPC>
                        <CenaPoSleve>1</CenaPoSleve>
                        <NesklPolozka>
                            <TypZarDoby>N</TypZarDoby>
                            <ZarDoba>0</ZarDoba>
                            <PredPC>0</PredPC>
                        </NesklPolozka>
                    </Polozka>
                    {{/each}}
                </SeznamPolozek>
                <MojeFirma>
                    <Nazev>eTabak</Nazev>
                    <Adresa>
                        <Ulice>Podměstí 2125</Ulice>
                        <Misto>Žatec</Misto>
                        <PSC>43801</PSC>
                        <Stat>Česká republika</Stat>
                        <KodStatu>CZ</KodStatu>
                    </Adresa>
                    <ObchNazev>eTabak</ObchNazev>
                    <ObchAdresa>
                        <Ulice>Podměstí 2125</Ulice>
                        <Misto>Žatec</Misto>
                        <PSC>43801</PSC>
                        <Stat>Česká republika</Stat>
                        <KodStatu>CZ</KodStatu>
                    </ObchAdresa>
                    <FaktNazev>eTabak</FaktNazev>
                    <FaktAdresa>
                        <Ulice>Podměstí 2125</Ulice>
                        <Misto>Žatec</Misto>
                        <PSC>43801</PSC>
                        <Stat>Česká republika</Stat>
                        <KodStatu>CZ</KodStatu>
                    </FaktAdresa>
                    <Tel>
                        <Pred>420</Pred>
                        <Cislo>NEZNAME</Cislo>
                        <Klap>NEZNAME</Klap>
                    </Tel>
                    <Fax>
                        <Pred>NEZNAME</Pred>
                        <Cislo>NEZNAME</Cislo>
                        <Klap>NEZNAME</Klap>
                    </Fax>
                    <Mobil>
                        <Pred>NEZNAME</Pred>
                        <Cislo>NEZNAME</Cislo>
                    </Mobil>
                    <EMail>NEZNAME</EMail>
                    <WWW>etabak.com</WWW>
                    <ICO></ICO>
                    <DIC></DIC>
                    <Banka></Banka>
                    <Ucet></Ucet>
                    <KodBanky></KodBanky>
                    <KodPartn></KodPartn>
                    <FyzOsoba></FyzOsoba>
                </MojeFirma>
            </ObjPrij>
        </SeznamObjPrij>
    </MoneyData>'
    ]
];
