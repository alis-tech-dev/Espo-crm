define(['action-handler'], Dep => {
	return class extends Dep {
		init() {
			this.view.hideHeaderActionItem('performWork');
		}

		actionPerformWorkMain() {
			this.view
				.getCollectionFactory()
				.create('WorkPerformed', collection => {
					collection.where = [
						{
							type: 'equals',
							attribute: 'assignedUserId',
							value: this.view.getUser().id,
						},
						{
							type: 'equals',
							attribute: 'parentType',
							value: 'ProductionOrder',
						},
						{
							type: 'equals',
							attribute: 'parentId',
							value: this.view.model.id,
						},
						{
							type: 'isNull',
							attribute: 'dateEnd',
						},
					];

					collection.fetch().then(() => {
						if (collection.at(0)) {
							this.openModal(collection.at(0));
						} else {
							this.openModal(null);
						}
					});
				});
		}

		openModal(model) {
			this.view.createView(
				'modal',
				'views/modals/edit',
				{
					scope: 'WorkPerformed',
					model,
					id: model?.id,
					attributes: {
						productionOrderId: this.view.model.id,
					},
				},
				modalView => {
					modalView.render();

					this.view.listenTo(modalView, 'close', () => {
						this.view.model.fetch();

						this.view.model.trigger('update-all');
					});
				},
			);
		}
	};
});
