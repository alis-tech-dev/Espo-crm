define('views/fields/cronselect', ['views/fields/base'], function (Dep) {
	return Dep.extend({
		type: 'text',

		listTemplate: 'fields/text/list',

		detailTemplate: 'main:fields/cronselect/detail',

		editTemplate: 'main:fields/cronselect/edit',

		events: {},

		data: function () {
			var data = Dep.prototype.data.call(this);
			if (!this.model.has(this.name) || this.model.get(this.name) == null)
				return {};
			var cron = this.model.get(this.name).split(';');
			data.isDayChecked = cron[1] === 'D';
			data.isMonthChecked = cron[1] === 'M';
			data.isYearChecked = cron[1] === 'Y';
			data.amountOfDays = cron[0];
			return data;
		},

		setup: function () {
			Dep.prototype.setup.call(this);
		},

		fetch: function () {
			var data = {};
			data[this.name] =
				this.$el.find('#dateNumber').val() +
				';' +
				this.$el.find('#typeOfDate').val();
			return data;
		},
	});
});
