define(['views/base'], function (Dep) {
	return class extends Dep {
		template = 'main:quote/entry';

		setup() {
			super.setup();

			const promises = [];

			promises.push(
				this.createView(
					'items',
					'main:views/sales-order/fields/items',
					{
						el: this.options.el + ` .field-recordList`,
						model: this.model,
						name: 'items',
						scope: 'SalesOrder',
						params: this.getMetadata().get([
							'entityDefs',
							'SalesOrder',
							'fields',
							'items',
						]),
						mode: this.options.mode,
						inlineEditDisabled: true,
					},
				),
			);

			promises.push(
				this.createView('files', 'views/fields/attachment-multiple', {
					el: this.options.el + ` .field-files`,
					model: this.model,
					name: 'files',
					mode: this.options.mode,
					inlineEditDisabled: true,
				}),
			);

			promises.push(
				this.createView('description', 'views/fields/text', {
					el: this.options.el + ` .field-description`,
					model: this.model,
					name: 'description',
					mode: this.options.mode,
					inlineEditDisabled: true,
				}),
			);

			this.wait(Promise.all(promises));
		}

		setMode(mode) {
			return Promise.all([
				this.getView('items').setMode(mode),
				this.getView('files').setMode(mode),
				this.getView('description').setMode(mode),
			]);
		}
	};
});
