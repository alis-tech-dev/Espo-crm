<?php

namespace Espo\Modules\Main\Controllers;

use Espo\Core\Templates\Controllers\Base;

class ClockIn extends Base
{
}
