<?php

namespace Espo\Modules\Main\Controllers;

use Espo\Core\Templates\Controllers\CategoryTree;

class Smernice extends CategoryTree
{
}
