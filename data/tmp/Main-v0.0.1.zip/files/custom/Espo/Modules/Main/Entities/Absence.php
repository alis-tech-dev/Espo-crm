<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\Event;

class Absence extends Event
{
	protected $entityType = "Absence";
}
