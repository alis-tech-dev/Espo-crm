<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\Base;

class ClockIn extends Base
{
	protected $entityType = "ClockIn";
}
