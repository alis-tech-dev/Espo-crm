<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\Base;

class HumanResources extends Base
{
	protected $entityType = "HumanResources";
}
