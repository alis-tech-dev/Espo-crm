<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\Event;

class Porady extends Event
{
	protected $entityType = "Porady";
}
