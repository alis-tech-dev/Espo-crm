<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\Base;

class ProductDatabase extends Base
{
	protected $entityType = "ProductDatabase";
}
