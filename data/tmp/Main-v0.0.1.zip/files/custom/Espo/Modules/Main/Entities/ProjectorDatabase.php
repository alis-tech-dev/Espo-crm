<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\Base;

class ProjectorDatabase extends Base
{
	protected $entityType = "ProjectorDatabase";
}
