<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\Base;

class RequestForm extends Base
{
	protected $entityType = "RequestForm";
}
