<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\Base;

class RequestItem extends Base
{
	protected $entityType = "RequestItem";
}
