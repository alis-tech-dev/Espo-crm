<?php

namespace Espo\Modules\Main\Entities;

use Espo\Core\Templates\Entities\CategoryTree;

class Smernice extends CategoryTree
{
	protected $entityType = "Smernice";
}
