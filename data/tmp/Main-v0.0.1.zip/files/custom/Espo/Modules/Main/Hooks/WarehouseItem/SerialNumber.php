<?php

namespace Espo\Modules\Main\Hooks\WarehouseItem;

use Espo\Core\Hook\Hook\BeforeSave;
use Espo\Core\ORM\EntityManager;
use Espo\Entities\NextNumber;
use Espo\Modules\ProductBase\Entities\Product;
use Espo\ORM\Entity;
use Espo\ORM\Repository\Option\SaveOptions;
use Espo\Modules\WarehouseManagement\Tools\Stock\Manager\DefaultStockManager;

class SerialNumber implements BeforeSave
{
    public function __construct(
        private readonly EntityManager $entityManager,
    ) {
    }

    public function beforeSave(Entity $entity, SaveOptions $options): void
    {
        if (!$options->get(DefaultStockManager::TRIGGERED_BY_STOCK_MANAGER)) {
            return;
        }

        $product = $this
            ->entityManager
            ->getRDBRepository('WarehouseItem')
            ->getRelation($entity, 'product')
            ->findOne();

        if (!$product) {
            return;
        }

        $this->entityManager->getTransactionManager()->start();

        $nextNumber = $this->entityManager
            ->getRDBRepository(NextNumber::ENTITY_TYPE)
            ->where([
                'fieldName' => 'serialNumber',
                'entityType' => 'WarehouseItem',
                'productId' => $product->getId(),
            ])
            ->forUpdate()
            ->findOne();

        if (!$nextNumber) {
            $nextNumber = $this->entityManager->getNewEntity(NextNumber::ENTITY_TYPE);

            $nextNumber->set([
                'fieldName' => 'serialNumber',
                'entityType' => 'WarehouseItem',
                'productId' => $product->getId(),
                'value' => 1
            ]);
        }

        $entity->set('serialNumber', $this->composeNumberAttribute($product, $nextNumber));

        $value = $nextNumber->get('value');

        if (!$value) {
            $value = 1;
        }

        $value++;

        $nextNumber->set('value', $value);

        $this->entityManager->saveEntity($nextNumber);

        $this->entityManager->getTransactionManager()->commit();
    }

    public function composeNumberAttribute(Product $product, NextNumber $nextNumber): string
    {
        return $product->get('productCode') . '_' . str_pad($nextNumber->get('value'), 5, '0', STR_PAD_LEFT);
    }
}
