<?php

namespace Espo\Modules\Main\Hooks\WorkPerformed;

use Espo\Core\Hook\Hook\BeforeSave;
use Espo\Core\Record\CreateParams;
use Espo\ORM\Entity;
use Espo\ORM\Repository\Option\SaveOptions;
use Espo\Modules\WarehouseManagement\Services\GoodsReceipt as GoodsReceiptService;
use Espo\Modules\WarehouseManagement\Entities\GoodsReceipt as GoodsReceiptEntity;
use Espo\Core\ORM\EntityManager;
use Espo\Entities\NextNumber;
use LogicException;

class CreateGoodsIssue implements BeforeSave
{
    public function __construct(
        private readonly EntityManager $entityManager,
        private readonly GoodsReceiptService $goodsReceiptService
    ) {
    }

    public function beforeSave(Entity $entity, SaveOptions $options): void
    {
        if ($entity->get('processed') || is_null($entity->get('producedAmount')) || $entity->get('producedAmount') == 0) {
            return;
        }

        $productionOrderId = $entity->get('productionOrderId') ?? throw new LogicException();
        $productionOrder = $this->entityManager->getEntityById('ProductionOrder', $productionOrderId) ?? throw new LogicException();

        $productName = $productionOrder->get('productName') ?? throw new LogicException();

        $i = 0;

        for ($i = 0; $i < $entity->get('producedAmount'); $i++) {
            $autoIncrementValue = $this->getNextAutoIncrementValue();

            $productDatabaseEntityName = $productName . '_' . str_pad($autoIncrementValue, 5, '0', STR_PAD_LEFT);

            $attributes = [
                'name' => $productDatabaseEntityName,
                'productId' => $productionOrder->get('productId'),
                'salesOrderId' => $productionOrder->get('salesOrderId'),
                'productAvailability' => 'available',
            ];

            if ($productionOrder->get('productWarehouseId') === /* Prostějov */ '65006dec0dfcb5f11') {
                $attributes['productAvailability'] = 'inStockAledo';
            } else if ($productionOrder->get('productWarehouseId') === /* Brno */ '650067377ec266179') {
                $attributes['productAvailability'] = 'inStock';
            }

            $this->entityManager->createEntity('ProductDatabase', $attributes);
        }

        $this->goodsReceiptService->create((object)[
            'name' => 'Příjemka z výrobního příkazu',
            'status' => GoodsReceiptEntity::STATUS_PROCESSING,
            'warehouseId' => $productionOrder->get('productWarehouseId'),
            'parentId' => $productionOrder->getId(),
            'parentType' => $productionOrder->getEntityType(),
            'itemsRecordList' => [
                (object)[
                    'productId' => $productionOrder->get('productId'),
                    'quantity' => $entity->get('producedAmount')
                ]
            ]
        ], CreateParams::create());

        // Mark as processed
        $entity->set('processed', true);
    }

    private function getNextAutoIncrementValue(): int
    {
        $this->entityManager->getTransactionManager()->start();

        $nextNumber = $this->entityManager
            ->getRDBRepository(NextNumber::ENTITY_TYPE)
            ->where([
                'fieldName' => 'name',
                'entityType' => 'ProductDatabase',
            ])
            ->forUpdate()
            ->findOne();

        if (!$nextNumber) {
            $nextNumber = $this->entityManager->getNewEntity(NextNumber::ENTITY_TYPE);

            $nextNumber->set([
                'fieldName' => 'name',
                'entityType' => 'ProductDatabase',
                'value' => 1
            ]);
        }

        $value = $nextNumber->get('value');

        if (!$value) {
            $value = 1;
        }

        $value++;

        $nextNumber->set('value', $value);

        $this->entityManager->saveEntity($nextNumber);

        $this->entityManager->getTransactionManager()->commit();

        return $value;
    }
}
