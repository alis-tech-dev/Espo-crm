<?php

namespace Espo\Modules\Main\Repositories;

use Espo\Core\Templates\Repositories\Event;

class Absence extends Event
{
}
