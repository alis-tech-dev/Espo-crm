<?php

namespace Espo\Modules\Main\Repositories;

use Espo\Core\Templates\Repositories\Base;

class SmerniceItem extends Base
{
}
