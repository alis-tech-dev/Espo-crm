<?php

namespace Espo\Modules\Main\Services;

use Espo\Core\Templates\Services\Base;

class Complaint extends Base
{
}
