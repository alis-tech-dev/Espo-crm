<?php

namespace Espo\Modules\Main\Services;

use Espo\Core\Templates\Services\Base;

class InternalAgenda extends Base
{
}
