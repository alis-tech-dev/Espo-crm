<?php

namespace Espo\Modules\Main\Services;

use Espo\Core\Templates\Services\Event;

class Porady extends Event
{
}
