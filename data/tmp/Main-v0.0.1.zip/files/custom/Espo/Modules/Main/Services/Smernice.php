<?php

namespace Espo\Modules\Main\Services;

use Espo\Core\Templates\Services\CategoryTree;

class Smernice extends CategoryTree
{
}
