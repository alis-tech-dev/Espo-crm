<?php

namespace Espo\Modules\Pohoda\Hooks\Synchronize;

use Espo\Core\Utils\Log;
use Espo\ORM\EntityManager;
use Espo\Core\Hook\Hook\AfterSave;
use Espo\Modules\Crm\Entities\Account;
use Espo\ORM\Repository\Option\SaveOptions;

class SynchronizeAccount
{
    public function __construct(
        private readonly Log           $log,
        private readonly EntityManager $entityManager
    ){}

    public function afterSave(Account $entity, array $options): void
    {
        $this->log->debug("ddddd", []);
        
    }
}
