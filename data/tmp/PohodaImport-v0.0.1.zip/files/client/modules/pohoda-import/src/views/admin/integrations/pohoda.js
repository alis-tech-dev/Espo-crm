"use strict";define(["views/admin/integrations/edit"],e=>class extends e{});
