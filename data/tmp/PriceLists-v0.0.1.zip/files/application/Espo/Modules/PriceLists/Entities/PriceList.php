<?php

namespace Espo\Modules\PriceLists\Entities;

class PriceList extends \Espo\Core\Templates\Entities\Base {
    
}