<?php

namespace Espo\Modules\PriceLists\Repositories;

class PriceList extends \Espo\Core\Templates\Repositories\Base
{
    
}