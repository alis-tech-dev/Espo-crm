<?php

namespace Espo\Modules\ProductBase\Controllers;

class Product extends \Espo\Core\Templates\Controllers\Base
{
}
