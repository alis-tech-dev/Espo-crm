<?php

namespace Espo\Modules\ProductBase\Controllers;

class ProductCategory extends \Espo\Core\Templates\Controllers\CategoryTree
{
}
