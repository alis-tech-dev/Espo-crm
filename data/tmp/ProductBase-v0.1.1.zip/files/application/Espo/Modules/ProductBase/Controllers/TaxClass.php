<?php

namespace Espo\Modules\ProductBase\Controllers;

class TaxClass extends \Espo\Core\Templates\Controllers\Base
{
}
