<?php

namespace Espo\Modules\ProductBase\Entities;

class ProductCategory extends \Espo\Core\Templates\Entities\CategoryTree
{
    public const ENTITY_TYPE = 'ProductCategory';
}
