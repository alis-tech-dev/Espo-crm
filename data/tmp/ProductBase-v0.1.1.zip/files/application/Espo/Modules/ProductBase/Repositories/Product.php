<?php

namespace Espo\Modules\ProductBase\Repositories;

class Product extends \Espo\Core\Templates\Repositories\Base
{
}
