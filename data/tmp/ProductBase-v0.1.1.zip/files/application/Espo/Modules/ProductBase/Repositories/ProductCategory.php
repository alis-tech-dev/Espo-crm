<?php

namespace Espo\Modules\ProductBase\Repositories;

class ProductCategory extends \Espo\Core\Repositories\CategoryTree
{
}
