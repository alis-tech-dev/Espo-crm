<?php

namespace Espo\Modules\ProductBase\Repositories;

class TaxClass extends \Espo\Core\Templates\Repositories\Base
{
}
