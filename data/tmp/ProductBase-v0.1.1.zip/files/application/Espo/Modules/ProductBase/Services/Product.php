<?php

namespace Espo\Modules\ProductBase\Services;

class Product extends \Espo\Core\Templates\Services\Base
{
}
