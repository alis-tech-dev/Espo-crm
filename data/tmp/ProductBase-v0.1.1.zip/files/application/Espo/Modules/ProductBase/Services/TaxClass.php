<?php

namespace Espo\Modules\ProductBase\Services;

class TaxClass extends \Espo\Core\Templates\Services\Base
{
    protected $mandatorySelectAttributeList = ['rate'];
}
