define(['views/fields/currency'], function (Dep) {
    return class extends Dep {
        // jshint ignore:start
        editTemplate = 'fields/float/edit';
        // jshint ignore:end
    };
});
