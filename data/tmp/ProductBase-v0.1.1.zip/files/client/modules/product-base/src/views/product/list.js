define('product-base:views/product/list', 'views/list-with-categories', function (Dep) {

    return Dep.extend({

        quickCreate: false

    });

});
