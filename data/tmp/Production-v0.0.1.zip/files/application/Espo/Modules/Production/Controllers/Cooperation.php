<?php

namespace Espo\Modules\Production\Controllers;

class Cooperation extends \Espo\Core\Templates\Controllers\Base
{
}
