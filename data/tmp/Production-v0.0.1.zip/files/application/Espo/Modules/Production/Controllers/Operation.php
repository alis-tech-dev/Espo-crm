<?php

namespace Espo\Modules\Production\Controllers;

class Operation extends \Espo\Core\Templates\Controllers\Base
{
}
