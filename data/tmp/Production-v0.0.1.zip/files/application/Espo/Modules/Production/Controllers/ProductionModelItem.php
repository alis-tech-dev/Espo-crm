<?php

namespace Espo\Modules\Production\Controllers;

class ProductionModelItem extends \Espo\Core\Templates\Controllers\Base
{
}
