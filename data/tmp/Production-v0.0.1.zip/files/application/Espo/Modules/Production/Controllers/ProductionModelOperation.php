<?php

namespace Espo\Modules\Production\Controllers;

class ProductionModelOperation extends \Espo\Core\Templates\Controllers\Base
{
}
