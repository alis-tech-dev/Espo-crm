<?php

namespace Espo\Modules\Production\Controllers;

class WorkCenter extends \Espo\Core\Templates\Controllers\Base
{
}
