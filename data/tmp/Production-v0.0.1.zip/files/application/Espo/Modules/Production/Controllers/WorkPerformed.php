<?php

namespace Espo\Modules\Production\Controllers;

class WorkPerformed extends \Espo\Core\Templates\Controllers\Base
{
}
