<?php

namespace Espo\Modules\Production\Entities;

class Cooperation extends \Espo\Core\Templates\Entities\Base
{

}
