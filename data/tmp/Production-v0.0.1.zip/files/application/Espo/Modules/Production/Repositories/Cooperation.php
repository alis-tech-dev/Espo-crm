<?php

namespace Espo\Modules\Production\Repositories;

class Cooperation extends \Espo\Core\Templates\Repositories\Base
{

}
