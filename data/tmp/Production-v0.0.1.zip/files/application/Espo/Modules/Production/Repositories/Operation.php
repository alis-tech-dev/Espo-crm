<?php

namespace Espo\Modules\Production\Repositories;

class Operation extends \Espo\Core\Templates\Repositories\Base
{

}
