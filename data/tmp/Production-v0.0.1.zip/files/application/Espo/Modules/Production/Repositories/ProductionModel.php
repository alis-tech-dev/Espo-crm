<?php

namespace Espo\Modules\Production\Repositories;

class ProductionModel extends \Espo\Core\Templates\Repositories\Base
{

}
