<?php

namespace Espo\Modules\Production\Repositories;

class ProductionModelItem extends \Espo\Core\Templates\Repositories\Base
{

}
