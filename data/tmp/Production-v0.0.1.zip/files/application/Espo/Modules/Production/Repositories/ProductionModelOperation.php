<?php

namespace Espo\Modules\Production\Repositories;

class ProductionModelOperation extends \Espo\Core\Templates\Repositories\Base
{

}
