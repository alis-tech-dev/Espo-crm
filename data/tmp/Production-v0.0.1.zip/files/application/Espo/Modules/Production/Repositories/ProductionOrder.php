<?php

namespace Espo\Modules\Production\Repositories;

class ProductionOrder extends \Espo\Core\Templates\Repositories\Base
{

}
