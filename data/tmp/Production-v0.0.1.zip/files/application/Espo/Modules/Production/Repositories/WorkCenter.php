<?php

namespace Espo\Modules\Production\Repositories;

class WorkCenter extends \Espo\Core\Templates\Repositories\Base
{

}
