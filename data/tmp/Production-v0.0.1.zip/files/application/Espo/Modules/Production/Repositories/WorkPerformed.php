<?php

namespace Espo\Modules\Production\Repositories;

class WorkPerformed extends \Espo\Core\Templates\Repositories\Base
{
    
}