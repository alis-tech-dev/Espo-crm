<?php

namespace Espo\Modules\Production\Services;

class Cooperation extends \Espo\Core\Templates\Services\Base
{

}
