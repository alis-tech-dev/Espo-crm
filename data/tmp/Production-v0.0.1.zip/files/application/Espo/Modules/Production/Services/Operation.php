<?php

namespace Espo\Modules\Production\Services;

class Operation extends \Espo\Core\Templates\Services\Base
{

}
