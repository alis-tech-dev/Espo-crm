<?php

namespace Espo\Modules\Production\Services;

class ProductionModel extends \Espo\Core\Templates\Services\Base
{
}
