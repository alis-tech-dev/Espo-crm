<?php

namespace Espo\Modules\Production\Services;

class ProductionModelItem extends \Espo\Core\Templates\Services\Base
{

}
