<?php

namespace Espo\Modules\Production\Services;

class ProductionModelOperation extends \Espo\Core\Templates\Services\Base
{

}
