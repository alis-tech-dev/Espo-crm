<?php

namespace Espo\Modules\Production\Services;

class WorkCenter extends \Espo\Core\Templates\Services\Base
{

}
