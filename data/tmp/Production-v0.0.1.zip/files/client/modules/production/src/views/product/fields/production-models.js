define(['views/fields/link-multiple-with-primary'], Dep => {
	return class extends Dep {
		primaryLink = 'defaultProductionModel';
	};
});
