define(['action-handler'], Dep => {
	return class extends Dep {
		async actionConvertToSalesOrder() {
			const model = this.view.model;

			const view = await this.view.createView(
				'modal',
				'quote-conversion:views/quote/modals/convert-to-sales-order',
				{
					entriesData: model.get('quoteEntryData'),
					itemsRecordList: model.get('itemsRecordList'),
				},
			);

			view.once('selected', async data => {
				view.close();

				await this.createSalesOrder(data[0], data[1]);
			});

			await view.render();
		}

		async createSalesOrder(items, entryData) {
			const itemFieldsToCopy = [
				'name',
				'quantity',
				'listPrice',
				'listPriceCurrency',
				'unitPrice',
				'unitPriceCurrency',
				'amount',
				'amountCurrency',
				'entryKey',
				'taxRate',
				'productId',
				'order',
			];

			const newItems = items.map(item => {
				const newItem = {};

				for (const field of itemFieldsToCopy) {
					newItem[field] = Espo.Utils.cloneDeep(item[field]);
				}

				return newItem;
			});

			Espo.Ui.notify(' ... ');

			const id = this.view.model.id;
			const response = await Espo.Ajax.getRequest(
				'QuoteConversion/salesOrderAttributes/' + id,
			);

			const attributes = response.attributes;

			attributes['itemsRecordList'] = newItems;
			attributes['salesOrderEntryData'] = entryData;

			const router = this.view.getRouter();

			const url = '#SalesOrder/create';
			const returnDispatchParams = {
				controller: 'Quote',
				action: 'view',
				options: {
					id,
					isReturn: true,
				},
			};

			const options = {
				attributes,
				focusForCreate: true,
				returnUrl: router.getCurrentUrl(),
				returnDispatchParams: returnDispatchParams,
			};

			router.navigate(url, { trigger: false });
			router.dispatch('SalesOrder', 'create', options);

			Espo.Ui.notify(false);
		}
	};
});
