<?php

namespace Espo\Modules\Reclamations\Controllers;

class Reclamation extends \Espo\Core\Templates\Controllers\Base
{
}
