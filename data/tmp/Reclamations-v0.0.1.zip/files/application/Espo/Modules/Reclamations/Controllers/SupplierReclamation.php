<?php

namespace Espo\Modules\Reclamations\Controllers;

class SupplierReclamation extends \Espo\Core\Templates\Controllers\Base
{
}
