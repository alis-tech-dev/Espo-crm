<?php

namespace Espo\Modules\Reclamations\Entities;

class SupplierReclamation extends \Espo\Core\Templates\Entities\Base
{
}
