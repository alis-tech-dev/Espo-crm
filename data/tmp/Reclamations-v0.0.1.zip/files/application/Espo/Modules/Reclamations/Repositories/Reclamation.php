<?php

namespace Espo\Modules\Reclamations\Repositories;

class Reclamation extends \Espo\Core\Templates\Repositories\Base
{
}
