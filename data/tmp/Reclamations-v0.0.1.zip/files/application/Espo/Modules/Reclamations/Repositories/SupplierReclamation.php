<?php

namespace Espo\Modules\Reclamations\Repositories;

class SupplierReclamation extends \Espo\Core\Templates\Repositories\Base
{
}
