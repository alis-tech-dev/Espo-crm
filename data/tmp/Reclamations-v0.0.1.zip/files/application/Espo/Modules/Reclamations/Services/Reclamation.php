<?php

namespace Espo\Modules\Reclamations\Services;

class Reclamation extends \Espo\Core\Templates\Services\Base
{
}
