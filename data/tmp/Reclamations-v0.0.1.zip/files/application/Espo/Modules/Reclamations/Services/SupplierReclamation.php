<?php

namespace Espo\Modules\Reclamations\Services;

class SupplierReclamation extends \Espo\Core\Templates\Services\Base
{
}
