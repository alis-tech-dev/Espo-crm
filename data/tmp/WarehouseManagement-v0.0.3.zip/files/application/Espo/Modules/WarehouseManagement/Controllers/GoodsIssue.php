<?php

namespace Espo\Modules\WarehouseManagement\Controllers;

use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Api\Request;

class GoodsIssue extends \Espo\Core\Templates\Controllers\Base
{

}
