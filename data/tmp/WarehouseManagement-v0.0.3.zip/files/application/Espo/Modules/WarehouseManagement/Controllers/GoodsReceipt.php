<?php

namespace Espo\Modules\WarehouseManagement\Controllers;

use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Api\Request;

class GoodsReceipt extends \Espo\Core\Templates\Controllers\Base
{

}
