<?php

namespace Espo\Modules\WarehouseManagement\Controllers;

class SupplierOrderItem extends \Espo\Core\Templates\Controllers\Base
{
}
