<?php

namespace Espo\Modules\WarehouseManagement\Controllers;

class WarehousePosition extends \Espo\Core\Templates\Controllers\Base
{
}
