<?php

namespace Espo\Modules\WarehouseManagement\Controllers;

class WarehouseTransfer extends \Espo\Core\Templates\Controllers\Base
{

}
