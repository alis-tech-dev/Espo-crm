<?php

namespace Espo\Modules\WarehouseManagement\Entities;

class SupplierOrder extends \Espo\Core\Templates\Entities\BasePlus
{
    public const ENTITY_TYPE = 'SupplierOrder';

    protected $entityType = 'SupplierOrder';
}
