<?php

namespace Espo\Modules\WarehouseManagement\Entities;

class SupplierOrderItem extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'SupplierOrderItem';

    protected $entityType = 'SupplierOrderItem';
}
