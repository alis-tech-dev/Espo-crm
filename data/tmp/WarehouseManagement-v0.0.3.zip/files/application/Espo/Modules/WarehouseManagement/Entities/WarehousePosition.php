<?php

namespace Espo\Modules\WarehouseManagement\Entities;

class WarehousePosition extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'WarehousePosition';
}
