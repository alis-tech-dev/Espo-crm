<?php

namespace Espo\Modules\WarehouseManagement\Entities;

class WarehouseValueRecord extends \Espo\Core\Templates\Entities\Base
{
    public const ENTITY_TYPE = 'WarehouseValueRecord';

    protected $entityType = 'WarehouseValueRecord';
}
