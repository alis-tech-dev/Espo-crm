<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

use Espo\ORM\Entity;

class GoodsIssue extends \Espo\Core\Templates\Repositories\Base
{

}
