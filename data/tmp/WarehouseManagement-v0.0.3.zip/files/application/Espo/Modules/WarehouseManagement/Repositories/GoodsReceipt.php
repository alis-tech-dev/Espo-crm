<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

class GoodsReceipt extends \Espo\Core\Templates\Repositories\Base
{
}
