<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

class SupplierOrder extends \Espo\Core\Templates\Repositories\BasePlus
{
}
