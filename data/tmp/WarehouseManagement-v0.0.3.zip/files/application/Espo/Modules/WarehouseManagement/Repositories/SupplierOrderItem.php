<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

class SupplierOrderItem extends \Espo\Core\Templates\Repositories\Base
{
}
