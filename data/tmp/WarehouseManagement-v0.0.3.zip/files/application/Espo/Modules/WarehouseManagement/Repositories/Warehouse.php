<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

class Warehouse extends \Espo\Core\Templates\Repositories\Base
{

}
