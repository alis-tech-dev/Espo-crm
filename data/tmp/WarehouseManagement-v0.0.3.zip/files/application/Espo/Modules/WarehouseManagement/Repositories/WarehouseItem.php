<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

class WarehouseItem extends \Espo\Core\Templates\Repositories\Base
{
}
