<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

class WarehousePosition extends \Espo\Core\Templates\Repositories\Base
{

}
