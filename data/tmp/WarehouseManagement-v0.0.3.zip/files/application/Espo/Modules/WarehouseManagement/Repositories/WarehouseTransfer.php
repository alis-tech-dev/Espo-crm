<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

class WarehouseTransfer extends \Espo\Core\Templates\Repositories\Base
{

}
