<?php

namespace Espo\Modules\WarehouseManagement\Repositories;

class WarehouseValueRecord extends \Espo\Core\Templates\Repositories\Base
{
}
