<?php

namespace Espo\Modules\WarehouseManagement\Services;

class SupplierOrderItem extends \Espo\Core\Templates\Services\Base
{
}
