<?php

namespace Espo\Modules\WarehouseManagement\Services;

class WarehouseValueRecord extends \Espo\Core\Templates\Services\Base
{
}
