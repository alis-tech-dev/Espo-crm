<?php

namespace Espo\Modules\WarehouseManagement\Tools\Stock\Hook;

class HookData
{
    public const ITEM = 'item';
    public const WAREHOUSE = 'warehouse';
}
