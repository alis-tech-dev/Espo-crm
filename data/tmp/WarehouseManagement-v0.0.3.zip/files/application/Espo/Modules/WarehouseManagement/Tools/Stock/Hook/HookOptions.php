<?php

namespace Espo\Modules\WarehouseManagement\Tools\Stock\Hook;

class HookOptions
{
    public const SILENT = 'silent';
}
