define('warehouse-management:views/goods-receipt/fields/warehouse', ['warehouse-management:views/fields/type-aware-link'], function (Dep) {
    return Dep.extend({});
});
