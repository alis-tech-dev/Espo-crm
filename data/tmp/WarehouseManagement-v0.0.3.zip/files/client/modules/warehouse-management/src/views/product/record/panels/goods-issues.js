define(['warehouse-management:views/product/record/panels/goods-receipts'], function (Dep) {
    return class extends Dep {
        // jshint ignore:start
        scope = 'GoodsIssue'
        // jshint ignore:end
    };
});
