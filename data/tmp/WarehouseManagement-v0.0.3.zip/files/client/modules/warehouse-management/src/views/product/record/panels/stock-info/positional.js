define('warehouse-management:views/product/record/panels/stock-info/positional', ['warehouse-management:views/product/record/panels/stock-info/base'], function (Dep) {
    return Dep.extend({


    });
});
