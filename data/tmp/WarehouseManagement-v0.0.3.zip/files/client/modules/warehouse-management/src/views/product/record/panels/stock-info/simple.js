define('warehouse-management:views/product/record/panels/stock-info/simple', ['warehouse-management:views/product/record/panels/stock-info/base'], function (Dep) {
    return Dep.extend({

    });
});
