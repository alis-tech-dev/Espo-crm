define('warehouse-management:views/settings/fields/stock-determination-strategy', ['views/fields/base'], function (Dep) {
    return Dep.extend({
        // TODO: implement
    });
});
