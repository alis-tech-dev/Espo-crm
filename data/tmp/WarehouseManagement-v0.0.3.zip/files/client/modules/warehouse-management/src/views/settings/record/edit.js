define('warehouse-management:views/settings/record/edit', ['views/settings/record/edit'], function (Dep) {
    return Dep.extend({

        layoutName: 'warehouseManagement'

    });
});
