define(["views/fields/link"], (Dep) => {
    return class extends Dep {
        //TODO: something here
    };
});

