define('warehouse-management:views/warehouse-item/fields/product', ['warehouse-management:views/fields/stockable-product'], function (Dep) {
    return Dep.extend({

    });
});
