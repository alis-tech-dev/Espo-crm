define('warehouse-management:views/warehouse-transfer/fields/warehouse-to', ['warehouse-management:views/fields/type-aware-link'], function (Dep) {
    return Dep.extend({

    });
});
